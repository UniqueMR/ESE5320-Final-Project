// #include<array>
// void sha(unsigned char* input_chunk, std::array<unsigned char, 32> &hash_value);
#include <iostream>
#include <string>
void sha(std::string input_chunk, unsigned char* output_hash);