#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <math.h>
#include <iostream>
#include <fstream>
#include <vector>
#define WIN_SIZE 4
#define PRIME 3
#define MODULUS 256
#define TARGET 2

#define BUFFER_SIZE 

void cdc(unsigned char* buffer, std::vector<std::string> &chunks, unsigned int buff_size);