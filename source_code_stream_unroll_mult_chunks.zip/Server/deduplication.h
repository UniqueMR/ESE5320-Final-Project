#include <cstdint>
#include <fstream>
#include <iostream>

void duplicate_encoding(int duplicate_idx, uint32_t &dup_outcode, unsigned char* file_buffer);