#include "sha.h"
#include <iostream>

int main(unsigned char*input)
{

sha(input,length,output);

}